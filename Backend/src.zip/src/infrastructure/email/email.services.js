import Mailgen from "mailgen";
import { passwordResetMailGenerator, verificationMailGenerator } from "./email.templates.js"
import { transporter } from "./email.config.js";
import { ApiError } from "../../utils/ApiError.js";



const sendEmail = async ( options ) => {

  const mailGenerator = new Mailgen({
    theme: "default",
    product: {
      name: "RBlogs",
      link: "https://RBlogs.com"
    }
  })

  const emailTextual = mailGenerator.generatePlaintext(options.mailgenContent)
  const emailHTML = mailGenerator.generate(options.mailgenContent)

  try {
    await transporter.sendMail({
      from: "https://RBlogs.com",
      to: options.email,
      subject: options.subject,
      text: emailTextual,
      html: emailHTML
    });
  } catch (error) {
    throw new ApiError(500, `Failed to send email.`);
  }
  
};

export const sendVerificationEmail = async (user, req, unHashedToken) => {
    try {
      await sendEmail({
        email: user?.email,
        subject: "Please verify your email",
        mailgenContent: verificationMailGenerator(
          user?.full_name,
          `${req.protocol}://${req.get("host")}/api/v1/user/verify-email/${unHashedToken}`
        ),
      })
    } catch (error) {
      throw new ApiError(500, `Failed to send verification email.`)
    }
}

export const sendFogotPasswordEmail = async (user, req, unHashedToken) => {
    try {
      await sendEmail({
        email: user?.email,
        subject: "Please reset your password.",
        mailgenContent: passwordResetMailGenerator(
          user?.full_name,
          `${req.protocol}://${req.get("host")}/api/v1/user/reset-password/${unHashedToken}`
        ),
      })
    } catch (error) {
      throw new ApiError(500, `Failed to reset password email.`)
    }
}